function Offspring = Operator(Population,gamma,beta0,alpha,delta,dmax,mu)
% The particle swarm optimization in MOFA

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    P_Dec   = Population.decs;     
    [N,D]   = size(P_Dec); 
    P_Obj   = Population.objs;
    Off_P   = zeros(N,D);    
    Problem = PROBLEM.Current();
    Off_P_Obj = zeros(N,Problem.M);    
    
    % Assign weights and Get gbest
    M = Problem.M;
    pk      = rand(M,1);
    sum_p   = sum(pk);
    wk = pk/sum_p;     
    temp_best= P_Obj(1,:);
    index   = 1;    
    for si=2:N
        if temp_best * wk   > P_Obj(si,:) * wk
            temp_best   = P_Obj(si,:);
            index       = si;
        end
    end
    gbest_P_Dec = P_Dec(index,:);
    
    
    %% Learning
    for i = 1 : N
        num=0;                
        for j= 1 : N            
            rij   = norm(P_Dec(i,:) - P_Dec(j,:)) / dmax;
            beta1 = beta0 * exp(-gamma*rij^2);
            ei    = delta .* unifrnd(-1,+1,[1,D]);
            
            if Dominates(P_Obj(j,:),P_Obj(i,:))
                Off_P(i,:) = P_Dec(i,:) + beta1 .* rand([1,D]) ...
                    .*(P_Dec(j,:)-P_Dec(i,:)) + alpha .* ei;
                num = num+1;
            end
            
            if num == 0
                Off_P(i,:) = gbest_P_Dec + alpha .* ei;
            end
            
            Lower = Problem.lower;
            Upper = Problem.upper;
            Off_P(i,:) = min(max(Off_P(i,:),Lower),Upper);
            Off_P_Obj(i,:)  = Problem.CalObj(Off_P(i,:));
            
            % Apply Mutation
            pm=(1-(i-1)/(Problem.maxFE-1))^(1/mu);
            if rand < pm
                Off_P(i,:) = Mutate(Off_P(i,:),pm,Problem.lower,Problem.upper);
                Off_P_Obj(i,:) = Problem.CalObj(Off_P(i,:));
                if Dominates(P_Obj(i,:),Off_P_Obj(i,:))
                    Off_P(i,:) = P_Dec(i,:);                    
                else
                    if rand < 0.5
                        Off_P(i,:) = P_Dec(i,:);                       
                    end
                end
            end            
        end                
    end   
	Offspring = SOLUTION(Off_P);
end